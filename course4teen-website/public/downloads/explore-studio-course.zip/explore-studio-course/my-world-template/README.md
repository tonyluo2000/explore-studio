# My Explore World

**This folder belongs to you.**

Your explorer, your companion, and your own projects live here. Course updates
never replace this folder:

- the course folder, `explore-studio-course`, is the **Course Kit**. Your
  teacher may hand out a newer copy of it at any time;
- this folder, `my-explore-world`, is your **Student Workspace**. It stays
  yours all year.

If `make-my-world.py` runs again, it only adds files that are missing. It never
changes or replaces a file that is already here.

| File or folder | What it is |
|---|---|
| `explorer.py` | Your explorer's name, appearance, personality, and favorite subject or interest. Run it to print your Explorer Card. |
| `companion.py` | Your companion's name, kind, personality, specialty or interest, and one future ability. Run it to print your Companion Card. |
| `projects/moon-compass/` | Your editable S02 Explorer Package. Validate and launch this copy. |

Run your files from inside this folder:

```console
python explorer.py
python companion.py
```

The cards show your values. They do not change the Trail yet: in S02 you
walk as Nova, the class example, and your Moon Compass `x`, `y`, and `color`
are what change the world.

The Moon Compass package is also yours. From the Course Kit folder, validate it
with:

```console
explore-package validate ../my-explore-world/projects/moon-compass
```

Running `make-my-world.py` again never changes that package. A fresh seed is
copied only when a file is missing.

Nothing in this folder is uploaded, and no account is involved. Keep a backup
copy if your teacher suggests one.
